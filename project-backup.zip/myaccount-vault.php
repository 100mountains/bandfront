<?php
$vault_content = '
<div class="vault-content">
    <h2>🎉 Welcome to The Vault! 🎉</h2>
    
    <p>Hello peeps! 😄✨</p>
    
    <p>🔥 I am now testing this area! We now have a code for use on therob.lol! Add the album to your basket, go to checkout and add the coupon there, you will see the price go to 0. once thats done you can click go to paypal. it wont go to paypal it will just give you the album 🚀</p>
    <p> 💥 I will be adding more albums and codes soon, so keep checking back! 💥</p>
    
    <p> 💖 Thank you for your support! 💖</p>

    <div class="album-section">
       more codes soon! 
    </div>
    
    <hr style="margin: 30px 0; border: 2px dashed #333;">
    
    
    <div style="text-align: center; margin-top: 30px;">
        <p>🎊 Enjoy your free music! 🎊</p>
        <p>💝 More goodies coming soon! 💝</p>
    </div>
</div>

<style>
.vault-content {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
}

.album-section {
    background: linear-gradient(135deg, #4a5568 0%, #553c9a 100%);
    border-radius: 15px;
    padding: 20px;
    margin: 20px 0;
    color: white;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
}

.codes-grid {
    background: rgba(255,255,255,0.1);
    border-radius: 10px;
    padding: 15px;
    margin-top: 15px;
    font-family: monospace;
    line-height: 1.8;
}

.codes-grid code {
    background: rgba(255,255,255,0.2);
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: bold;
}

.album-section h3 {
    margin-top: 0;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.album-section a {
    color: #ffeb3b;
    text-decoration: none;
    font-weight: bold;
}

.album-section a:hover {
    text-decoration: underline;
}
</style>
';

echo $vault_content;
?>